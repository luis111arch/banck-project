// Referencias a los elementos del DOM
const inputIngresos = document.getElementById("inputIngresos");
const inputAhorros = document.getElementById("inputAhorros");
const inputPagar = document.getElementById("inputPagar");

const btnActualizar = document.getElementById("btnActualizar");
const btnReset = document.getElementById("btnReset");

const toggleIngresos = document.getElementById("toggleIngresos");
const toggleAhorros = document.getElementById("toggleAhorros");
const togglePagar = document.getElementById("togglePagar");





// Datos iniciales del gráfico
let datos = {
  ingresos: 0,
  ahorros: 0,
  pagar: 0
};




// Estado de visibilidad de cada categoría
let visibles = {
  ingresos: true,
  ahorros: true,
  pagar: true
};





// Crear gráfico pastel
const ctx = document.getElementById("graficoPastel").getContext("2d");
const graficoPastel = new Chart(ctx, {
  type: "pie",
  data: {
    labels: ["Ingresos", "Ahorros", "Pagar"],
    datasets: [{
      data: [0, 0, 0],
      backgroundColor: ["#00c47c", "#00b4d8", "#ff595e"],
      borderWidth: 1
    }]
  },
  options: {
    responsive: true,
    plugins: {
      legend: {
        position: 'bottom',
        labels: {
          color: 'white'
        }
      }
    }
  }
});





// Función para actualizar el gráfico con nuevos datos
function actualizarGrafico() {
  // Tomar los valores de los inputs
  datos.ingresos = parseFloat(inputIngresos.value) || 0;
  datos.ahorros = parseFloat(inputAhorros.value) || 0;
  datos.pagar = parseFloat(inputPagar.value) || 0;

  // Construir nuevo array de datos basado en visibilidad
  const nuevasLabels = [];
  const nuevosDatos = [];
  const nuevosColores = [];

  if (visibles.ingresos) {
    nuevasLabels.push("Ingresos");
    nuevosDatos.push(datos.ingresos);
    nuevosColores.push("#00c47c");
  }
  if (visibles.ahorros) {
    nuevasLabels.push("Ahorros");
    nuevosDatos.push(datos.ahorros);
    nuevosColores.push("#00b4d8");
  }
  if (visibles.pagar) {
    nuevasLabels.push("Pagar");
    nuevosDatos.push(datos.pagar);
    nuevosColores.push("#ff595e");
  }

  // Actualizar datos del gráfico
  graficoPastel.data.labels = nuevasLabels;
  graficoPastel.data.datasets[0].data = nuevosDatos;
  graficoPastel.data.datasets[0].backgroundColor = nuevosColores;

  graficoPastel.update();
}

// Botón actualizar
btnActualizar.addEventListener("click", actualizarGrafico);

// Botón reset
btnReset.addEventListener("click", () => {
  inputIngresos.value = "";
  inputAhorros.value = "";
  inputPagar.value = "";

  datos = { ingresos: 0, ahorros: 0, pagar: 0 };
  visibles = { ingresos: true, ahorros: true, pagar: true };

  toggleIngresos.classList.add("activo");
  toggleAhorros.classList.add("activo");
  togglePagar.classList.add("activo");

  actualizarGrafico();
});

// Botones de filtro (ocultar/mostrar)
toggleIngresos.addEventListener("click", () => {
  visibles.ingresos = !visibles.ingresos;
  toggleIngresos.classList.toggle("activo");
  actualizarGrafico();
});

toggleAhorros.addEventListener("click", () => {
  visibles.ahorros = !visibles.ahorros;
  toggleAhorros.classList.toggle("activo");
  actualizarGrafico();
});

togglePagar.addEventListener("click", () => {
  visibles.pagar = !visibles.pagar;
  togglePagar.classList.toggle("activo");
  actualizarGrafico();
});
